#!/bin/bash

oc delete project pacman-app-cicd